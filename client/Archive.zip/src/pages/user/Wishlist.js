import React from 'react';
import UserNav from '../../components/nav/UserNav';

const Wishlist = () => {
  return (
    <div className='row'>
      <UserNav page={3} />

      <div className='col d-flex'>user Wishlist page</div>
    </div>
  );
};

export default Wishlist;
