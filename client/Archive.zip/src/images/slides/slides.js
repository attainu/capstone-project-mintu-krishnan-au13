const SLIDES = [
  {
    id: '001',
    category: 'Kitchen Appliances',
    image: require('../slides/slide1.svg').default,
  },
  {
    id: '002',
    category: 'Zip Services',
    image: require('../slides/slide2.svg').default,
  },
  {
    id: '003',
    category: 'Consumables',
    image: require('../slides/slide3.svg').default,
  },
  {
    id: '004',
    category: 'Cameras',
    image: require('../slides/slide4.svg').default,
  },
  {
    id: '005',
    category: 'Top Brands',
    image: require('../slides/slide5.svg').default,
  },
  {
    id: '006',
    category: 'Gaming',
    image: require('../slides/slide6.svg').default,
  },
  {
    id: '007',
    category: 'Cameras',
    image: require('../slides/slide4.svg').default,
  },
  {
    id: '008',
    category: 'Top Brands',
    image: require('../slides/slide5.svg').default,
  },
  {
    id: '009',
    category: 'Gaming',
    image: require('../slides/slide6.svg').default,
  },
];

export default SLIDES;
