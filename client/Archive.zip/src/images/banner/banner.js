const IMAGES = [
  {
    id: '001',
    image: require('../banner/banner1.jpeg').default,
  },
  {
    id: '002',
    image: require('../banner/banner2.jpeg').default,
  },
  {
    id: '003',
    image: require('../banner/banner3.jpeg').default,
  },
  {
    id: '004',
    image: require('../banner/banner4.jpeg').default,
  },
  {
    id: '005',
    image: require('../banner/banner5.jpeg').default,
  },
  {
    id: '006',
    image: require('../banner/banner6.jpeg').default,
  },
];

export default IMAGES;
